# When You Return - Quick Start Guide

## ✅ What We Completed Today

### **1. Database Migration ✅**
- Migrated from Lovable Supabase (`lkvnhskxbxzeohopqjcr`) to YOUR Supabase (`wjyanxstvbiqefmgpccb`)
- Applied all 12 migrations successfully
- Database schema is correct and ready

### **2. Demo Data Created ✅**
- **34 auth users** created with password `Demo123!`
  - 1 Super Admin: `headoffice@crowntechnologies.co.za`
  - 3 Companies: Ironhorse, Crowntechnologies, TomHVAC
  - 10 Installers: Blessing, Thami, Mark, James, David, Michael, Robert, William, Joseph, Charles
  - 20 Clients: client1@client.com through client20@client.com
- **Profiles, roles, and hierarchy** all set up
- **50 machines** created with realistic sensor data

### **3. Local Dev Server Fixed ✅**
- Updated `.env.local` to point to NEW Supabase
- Dev server restarted with correct credentials

---

## 🚀 **First Thing When You Return**

### **Test Your Demo Site:**

1. Go to: `http://localhost:8080`
2. Login:
   - Email: `headoffice@crowntechnologies.co.za`
   - Password: `Demo123!`

3. **You should now see:**
   - ✅ **50 machines** (not 27!)
   - ✅ **3 Companies** in dropdown (Ironhorse, Crowntechnologies, TomHVAC)
   - ✅ **10 Installers** under companies
   - ✅ **20 Clients** under installers
   - ✅ Full hierarchy working!

4. **Test different user roles:**
   - Company: `crown@crowntechnologies.co.za` / `Demo123!`
   - Installer: `blessing@installer.com` / `Demo123!`
   - Client: `client1@client.com` / `Demo123!`

---

## 📋 **Next Steps (Weekend Tasks)**

### **1. ESP32 Integration** 🔧
- Generate API keys from the dashboard
- Program ESP32 with one of the generated keys
- Test sensor data posting
- Verify data appears in dashboard

### **2. Deploy to Production (Optional)** 🚀
If you want to deploy with the NEW Supabase:

```powershell
# Build with new credentials
npm run build

# Upload dist/ folder to iotnexus.site
# (Same as before via cPanel FTP)
```

**Note:** Your current production site (`iotnexus.site`) is still using the OLD Lovable Supabase, which is fine for now!

---

## 🗂️ **Important Files**

### **Keep These:**
- ✅ `create-demo-users.js` - Script to create all 34 users
- ✅ `SETUP_DEMO.sql` - Creates profiles, roles, machines, hierarchy
- ✅ `CLEANUP_DEMO.sql` - Deletes all demo data when ready for production
- ✅ `RUN_DEMO_SETUP.md` - Complete setup instructions
- ✅ `ALL_MIGRATIONS_COMBINED.sql` - Database schema
- ✅ `DEPLOYMENT_GUIDE.md` - How to deploy to production
- ✅ `ESP32_INTEGRATION_GUIDE.md` - How to connect ESP32

### **Deleted (Obsolete):**
- ❌ All the manual email list files
- ❌ Old backup files (.backup, .NEW)
- ❌ Temporary change logs
- ❌ Old migration/deployment docs
- ❌ Context.zip (backup already extracted)

---

## 🔧 **If Something Doesn't Work**

### **Problem: Still seeing 27 machines**
**Solution:** 
1. Log out
2. Clear browser cache (`Ctrl+Shift+Delete`)
3. Open incognito window (`Ctrl+Shift+N`)
4. Login again at `http://localhost:8080`

### **Problem: Can't login with new accounts**
**Solution:**
Check `.env.local` file contains:
```
VITE_SUPABASE_URL=https://wjyanxstvbiqefmgpccb.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndqeWFueHN0dmJpcWVmbWdwY2NiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIyMzI4NDUsImV4cCI6MjA3NzgwODg0NX0.r1xQG8HYHioH8_ALGQTRO2wM5F2tAOhM-xe_eh3VxhY
```

Then restart dev server:
```powershell
# Stop all Node processes
Get-Process node | Stop-Process -Force

# Start dev server
npm run dev
```

### **Problem: Need to recreate demo data**
**Solution:**
```powershell
# Delete all demo data first
# Run CLEANUP_DEMO.sql in Supabase SQL Editor

# Then recreate
node create-demo-users.js
# Then run SETUP_DEMO.sql in SQL Editor
```

---

## 📊 **Current State**

### **NEW Supabase (wjyanxstvbiqefmgpccb):**
- ✅ Schema: Complete (12 migrations applied)
- ✅ Users: 34 auth users
- ✅ Profiles: 34 profiles
- ✅ Roles: Super admin (1), Company (3), Installer (10), Client (20)
- ✅ Machines: 50 machines
- ✅ Assignments: All hierarchy set up
- ✅ Local Dev: Connected ✅

### **OLD Lovable Supabase (lkvnhskxbxzeohopqjcr):**
- ⚠️ Still has your original data
- ⚠️ Production site (iotnexus.site) still connected to this
- ℹ️ Can keep for backup or migrate production later

---

## 🎯 **Quick Commands Reference**

```powershell
# Start dev server
npm run dev

# Create demo users (if needed again)
node create-demo-users.js

# Build for production
npm run build

# Stop all node processes
Get-Process node | Stop-Process -Force
```

---

## 📞 **Questions to Answer When You Return**

1. **Does the demo work?** (50 machines, 3 companies, hierarchy?)
2. **Do all user roles show correct data?** (super admin, company, installer, client)
3. **Ready to connect ESP32?**
4. **Want to deploy NEW Supabase to production, or keep using OLD one?**

---

**Have a great weekend! See you when you return! 🚀**

Password for all demo accounts: `Demo123!`

